from flask import Flask, render_template, request, redirect, send_file
import sqlite3
import pandas as pd
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
import io

app = Flask(__name__)

def obtener_conexion():
    return sqlite3.connect("database.db")

@app.route("/")
def index():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute("""
        SELECT u.nombre, u.direccion, c.mes, c.consumo_m3
        FROM usuarios u
        JOIN consumos c ON u.id = c.usuario_id
        ORDER BY c.id DESC
    """)
    registros = cursor.fetchall()
    conexion.close()
    return render_template("index.html", registros=registros)

@app.route("/agregar", methods=["GET", "POST"])
def agregar():
    if request.method == "POST":
        nombre = request.form["nombre"]
        direccion = request.form["direccion"]
        mes = request.form["mes"]
        consumo = float(request.form["consumo"])

        conexion = obtener_conexion()
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO usuarios (nombre, direccion) VALUES (?, ?)", (nombre, direccion))
        usuario_id = cursor.lastrowid
        cursor.execute("INSERT INTO consumos (usuario_id, mes, consumo_m3) VALUES (?, ?, ?)", (usuario_id, mes, consumo))
        conexion.commit()
        conexion.close()
        return redirect("/")
    return render_template("agregar.html")

@app.route("/exportar_pdf")
def exportar_pdf():
    conexion = obtener_conexion()
    df = pd.read_sql_query("""
        SELECT u.nombre AS Nombre,
               u.direccion AS Dirección,
               c.mes AS Mes,
               c.consumo_m3 AS Consumo_m3
        FROM usuarios u
        JOIN consumos c ON u.id = c.usuario_id
        ORDER BY c.id DESC
    """, conexion)
    conexion.close()

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph("Reporte de Consumo de Agua del Barrio", styles["Title"]))
    story.append(Spacer(1, 12))

    if df.empty:
        story.append(Paragraph("No hay datos registrados para mostrar.", styles["Normal"]))
    else:
        data = [df.columns.tolist()] + df.values.tolist()
        tabla = Table(data, repeatRows=1)
        tabla.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.lightblue),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
        ]))
        story.append(tabla)

    doc.build(story)
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name="reporte_consumo_agua.pdf")

if __name__ == "__main__":
    app.run(debug=True)
