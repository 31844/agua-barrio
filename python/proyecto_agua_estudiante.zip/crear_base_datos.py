import sqlite3

# Conexión a la base de datos (se crea automáticamente si no existe)
conexion = sqlite3.connect("database.db")
cursor = conexion.cursor()

# Crear tabla de usuarios
cursor.execute("""
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    direccion TEXT
)
""")

# Crear tabla de consumos
cursor.execute("""
CREATE TABLE IF NOT EXISTS consumos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER,
    mes TEXT,
    consumo_m3 REAL,
    FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
)
""")

conexion.commit()
conexion.close()

print("✅ Base de datos creada correctamente.")
